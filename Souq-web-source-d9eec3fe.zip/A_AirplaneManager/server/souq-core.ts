import crypto from "node:crypto";

export function hashPassword(password: string, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(actual, "hex"), Buffer.from(expected, "hex"));
}

export function issueToken() {
  return crypto.randomBytes(32).toString("hex");
}

export function tokenHash(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

export function validUsername(value: string) {
  return /^[A-Za-z\u0600-\u06FF][A-Za-z0-9\u0600-\u06FF_.-]{2,31}$/.test(value);
}

export function validPhone(value: string) {
  return /^(?:\+213|0)(?:5|6|7)\d{8}$/.test(value.replace(/[\s-]/g, ""));
}

export function validPrice(value: unknown) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 && n <= 1_000_000_000;
}

export function makeGiftCode() {
  return `SOUQ-${crypto.randomBytes(5).toString("hex").toUpperCase()}`;
}
