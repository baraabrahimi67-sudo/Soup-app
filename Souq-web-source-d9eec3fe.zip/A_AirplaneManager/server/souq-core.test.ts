import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword, validUsername, validPhone, validPrice, makeGiftCode, normalizeUsername } from "./souq-core";

describe("Souq security helpers", () => {
  it("hashes passwords without keeping plaintext and verifies them", () => {
    const stored = hashPassword("secret-123");
    expect(stored).not.toContain("secret-123");
    expect(verifyPassword("secret-123", stored)).toBe(true);
    expect(verifyPassword("wrong", stored)).toBe(false);
  });
  it("normalizes and validates usernames", () => {
    expect(normalizeUsername("  Brahimi  ")).toBe("brahimi");
    expect(validUsername("brahimi_22")).toBe(true);
    expect(validUsername("x")).toBe(false);
    expect(validUsername("bad space")).toBe(false);
  });
  it("accepts Algerian mobile numbers and positive prices only", () => {
    expect(validPhone("0550123456")).toBe(true);
    expect(validPhone("+213551234567")).toBe(true);
    expect(validPhone("021234567")).toBe(false);
    expect(validPrice(1500)).toBe(true);
    expect(validPrice(-1)).toBe(false);
    expect(validPrice("not-a-price")).toBe(false);
  });
  it("creates non-empty gift codes", () => {
    const a = makeGiftCode();
    const b = makeGiftCode();
    expect(a.startsWith("SOUQ-")).toBe(true);
    expect(a).not.toBe(b);
  });
});
