import express from "express";
import { createServer } from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { hashPassword, verifyPassword, issueToken, tokenHash, normalizeUsername, validUsername, validPhone, validPrice, makeGiftCode } from "./souq-core";
import { getDb, saveDb, id, now, publicProduct, publicUser, type User, type Product } from "./souq-db";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, "..");
const app = express();
app.use(express.json({ limit: "16mb" }));
const db = getDb();

function bearer(req: express.Request) { const value = req.headers.authorization || ""; return value.startsWith("Bearer ") ? value.slice(7) : ""; }
function currentUser(req: express.Request) { const session = db.sessions.find(s => s.tokenHash === tokenHash(bearer(req)) && s.userId); return session ? db.users.find(u => u.id === session.userId && u.active) : undefined; }
function isAdmin(req: express.Request) { return db.sessions.some(s => s.tokenHash === tokenHash(bearer(req)) && s.admin); }
function requireUser(req: express.Request, res: express.Response) { const user = currentUser(req); if (!user) { res.status(401).json({ error: "يجب تسجيل الدخول أولاً" }); return undefined; } return user; }
function requireAdmin(req: express.Request, res: express.Response) { if (!isAdmin(req)) { res.status(403).json({ error: "صلاحية المطوّر مطلوبة" }); return false; } return true; }
function sendToken(res: express.Response, token: string, user?: User, admin = false) { res.json({ token, user: user ? publicUser(user) : undefined, admin }); }
function newSession(userId?: string, admin = false) { const token = issueToken(); db.sessions = db.sessions.filter(s => new Date(s.createdAt).getTime() > Date.now() - 1000 * 60 * 60 * 24 * 30); db.sessions.push({ tokenHash: tokenHash(token), userId, admin, createdAt: now() }); saveDb(); return token; }

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "souq" }));
app.post("/api/auth/register", (req, res) => { const username = normalizeUsername(String(req.body.username || "")); const password = String(req.body.password || ""); if (!validUsername(username)) return res.status(400).json({ error: "اسم المستخدم يجب أن يكون من 3 إلى 32 محرفاً صالحاً" }); if (password.length < 6) return res.status(400).json({ error: "كلمة المرور يجب أن تكون 6 محارف على الأقل" }); if (db.users.some(u => u.username === username)) return res.status(409).json({ error: "اسم المستخدم مستخدم من قبل" }); const user: User = { id: id("usr"), username, passwordHash: hashPassword(password), coins: 30, createdAt: now(), active: true }; db.users.push(user); db.transactions.push({ id: id("txn"), userId: user.id, kind: "credit", amount: 30, reason: "الرصيد الابتدائي", createdAt: now() }); const token = newSession(user.id); saveDb(); sendToken(res, token, user); });
app.post("/api/auth/login", (req, res) => { const username = normalizeUsername(String(req.body.username || "")); const user = db.users.find(u => u.username === username && u.active); if (!user || !verifyPassword(String(req.body.password || ""), user.passwordHash)) return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" }); sendToken(res, newSession(user.id), user); });
app.post("/api/auth/logout", (req, res) => { db.sessions = db.sessions.filter(s => s.tokenHash !== tokenHash(bearer(req))); saveDb(); res.json({ ok: true }); });
app.get("/api/me", (req, res) => { const user = currentUser(req); if (!user) return res.status(401).json({ error: "غير مسجل" }); res.json({ user: publicUser(user) }); });

app.get("/api/products", (_req, res) => res.json({ products: db.products.filter(p => p.active).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(p => publicProduct(p, db.users)) }));
app.get("/api/products/mine", (req, res) => { const user = requireUser(req, res); if (!user) return; res.json({ products: db.products.filter(p => p.sellerId === user.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(p => publicProduct(p, db.users)) }); });
app.post("/api/products", (req, res) => { const user = requireUser(req, res); if (!user) return; const name = String(req.body.name || "").trim(); const description = String(req.body.description || "").trim(); const phone = String(req.body.phone || "").trim(); const region = String(req.body.region || "").trim(); const price = Number(req.body.price); const images = Array.isArray(req.body.images) ? req.body.images.filter((x: unknown) => typeof x === "string" && x.startsWith("data:image/")).slice(0, 4) : []; if (name.length < 2 || description.length < 5) return res.status(400).json({ error: "أكمل اسم المنتج ووصفه" }); if (!validPrice(price)) return res.status(400).json({ error: "السعر غير صالح" }); if (!validPhone(phone)) return res.status(400).json({ error: "رقم الهاتف غير صالح" }); if (!images.length) return res.status(400).json({ error: "أضف صورة واحدة على الأقل" }); if (user.coins < 5) return res.status(400).json({ error: "رصيدك غير كافٍ لنشر الإعلان" }); const product: Product = { id: id("prd"), sellerId: user.id, name, description, price, phone, region, images, createdAt: now(), active: true }; user.coins -= 5; db.products.push(product); db.transactions.push({ id: id("txn"), userId: user.id, kind: "debit", amount: 5, reason: "رسوم نشر إعلان", reference: product.id, createdAt: now() }); saveDb(); res.status(201).json({ product: publicProduct(product, db.users), user: publicUser(user) }); });
app.delete("/api/products/:id", (req, res) => { const user = requireUser(req, res); if (!user) return; const product = db.products.find(p => p.id === req.params.id); if (!product) return res.status(404).json({ error: "الإعلان غير موجود" }); if (product.sellerId !== user.id && !isAdmin(req)) return res.status(403).json({ error: "لا تملك صلاحية حذف هذا الإعلان" }); product.active = false; saveDb(); res.json({ ok: true }); });

app.post("/api/gifts/redeem", (req, res) => { const user = requireUser(req, res); if (!user) return; const code = String(req.body.code || "").trim().toUpperCase(); const gift = db.gifts.find(g => g.code === code && g.active); if (!gift || (gift.expiresAt && gift.expiresAt < now()) || gift.uses >= gift.maxUses) return res.status(400).json({ error: "كود الهدية غير صالح أو مستنفد" }); if (db.redemptions.some(r => r.giftId === gift.id && r.userId === user.id)) return res.status(409).json({ error: "سبق لك استخدام هذا الكود" }); gift.uses += 1; if (gift.uses >= gift.maxUses) gift.active = false; user.coins += gift.amount; db.redemptions.push({ id: id("red"), giftId: gift.id, userId: user.id, createdAt: now() }); db.transactions.push({ id: id("txn"), userId: user.id, kind: "credit", amount: gift.amount, reason: "استرداد كود هدية", reference: gift.id, createdAt: now() }); saveDb(); res.json({ message: `تهانينا! حصلت على ${gift.amount} عملة سوق`, user: publicUser(user) }); });

app.post("/api/admin/login", (req, res) => { if (!verifyPassword(String(req.body.password || ""), db.adminPasswordHash)) return res.status(401).json({ error: "كلمة مرور المطوّر غير صحيحة" }); sendToken(res, newSession(undefined, true), undefined, true); });
app.get("/api/admin/overview", (req, res) => { if (!requireAdmin(req, res)) return; res.json({ users: db.users.map(u => ({ ...publicUser(u), ads: db.products.filter(p => p.sellerId === u.id).length, activeAds: db.products.filter(p => p.sellerId === u.id && p.active).length })), products: db.products.map(p => publicProduct(p, db.users)), gifts: db.gifts }); });
app.post("/api/admin/coins", (req, res) => { if (!requireAdmin(req, res)) return; const user = db.users.find(u => u.id === req.body.userId); const amount = Number(req.body.amount); const kind = req.body.kind === "debit" ? "debit" : "credit"; if (!user || !Number.isInteger(amount) || amount <= 0 || (kind === "debit" && user.coins < amount)) return res.status(400).json({ error: "بيانات العملية غير صالحة" }); user.coins += kind === "credit" ? amount : -amount; db.transactions.push({ id: id("txn"), userId: user.id, kind, amount, reason: "عملية إدارية", createdAt: now() }); saveDb(); res.json({ user: publicUser(user) }); });
app.post("/api/admin/gifts", (req, res) => { if (!requireAdmin(req, res)) return; const amount = Number(req.body.amount); const maxUses = Number(req.body.maxUses); if (!Number.isInteger(amount) || amount <= 0 || !Number.isInteger(maxUses) || maxUses <= 0) return res.status(400).json({ error: "حدد قيماً صحيحة موجبة" }); const gift = { id: id("gift"), code: makeGiftCode(), amount, maxUses, uses: 0, createdAt: now(), active: true }; db.gifts.push(gift); saveDb(); res.status(201).json({ gift }); });
app.delete("/api/admin/products/:id", (req, res) => { if (!requireAdmin(req, res)) return; const product = db.products.find(p => p.id === req.params.id); if (!product) return res.status(404).json({ error: "الإعلان غير موجود" }); product.active = false; saveDb(); res.json({ ok: true }); });

async function startServer() {
  const server = createServer(app);
  const port = Number(process.env.PORT || 3000);
  const staticPath = process.env.NODE_ENV === "production" ? path.resolve(__dirname, "public") : path.resolve(root, "dist/public");
  app.use(express.static(staticPath));
  app.get("*", (_req, res) => res.sendFile(path.join(staticPath, "index.html")));
  server.listen(port, () => console.log(`Souq server running on http://localhost:${port}`));
}
startServer().catch(error => { console.error(error); process.exit(1); });
