import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { hashPassword } from "./souq-core";

export type User = { id: string; username: string; passwordHash: string; coins: number; createdAt: string; active: boolean };
export type Product = { id: string; sellerId: string; name: string; description: string; price: number; phone: string; region?: string; images: string[]; createdAt: string; active: boolean };
export type Transaction = { id: string; userId: string; kind: string; amount: number; reason: string; createdAt: string; reference?: string };
export type Gift = { id: string; code: string; amount: number; maxUses: number; uses: number; createdAt: string; expiresAt?: string; active: boolean };
export type Redemption = { id: string; userId: string; giftId: string; createdAt: string };
export type Session = { tokenHash: string; userId?: string; admin?: boolean; createdAt: string };
export type Db = { users: User[]; products: Product[]; transactions: Transaction[]; gifts: Gift[]; redemptions: Redemption[]; sessions: Session[]; adminPasswordHash: string };

const dir = process.env.SOUQ_DATA_DIR || path.resolve(process.cwd(), "data");
const file = path.join(dir, "souq.json");
let db: Db | null = null;

function seed(): Db {
  return { users: [], products: [], transactions: [], gifts: [], redemptions: [], sessions: [], adminPasswordHash: hashPassword(process.env.SOUQ_ADMIN_PASSWORD || "br2299") };
}

export function getDb() {
  if (!db) {
    fs.mkdirSync(dir, { recursive: true });
    try { db = JSON.parse(fs.readFileSync(file, "utf8")) as Db; } catch { db = seed(); saveDb(); }
    if (!db.adminPasswordHash) { db.adminPasswordHash = hashPassword(process.env.SOUQ_ADMIN_PASSWORD || "br2299"); saveDb(); }
  }
  return db;
}

export function saveDb() {
  if (!db) return;
  fs.mkdirSync(dir, { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, file);
}

export function id(prefix: string) { return `${prefix}_${crypto.randomBytes(9).toString("hex")}`; }
export function now() { return new Date().toISOString(); }
export function publicUser(user: User) { return { id: user.id, username: user.username, coins: user.coins, createdAt: user.createdAt, active: user.active }; }
export function publicProduct(product: Product, users: User[]) { const seller = users.find(u => u.id === product.sellerId); return { ...product, sellerName: seller?.username || "مستخدم" }; }
